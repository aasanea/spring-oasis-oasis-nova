# Abdullah BANK — continue from here

You are continuing **Abdullah BANK**, a TASI paper-trading desk.

The user is Arabic-speaking. Reply in Arabic unless they switch. Do not invent fake prices.

## Product (current, working)

TanStack Start + React 19 + Tailwind v4 + Zustand. **Not** the original FastAPI/Next split (that spec is in `docs/abdullahnote.md`).

- Live Tadawul last via Yahoo Finance chart API (`2222.SR`, `^TASI.SR`, `BZ=F`, `^TNX`)
- Real headlines: Google News RSS (AR/EN) + Yahoo news, filtered to Saudi/TASI names
- Paper fills at **live last**, 15.5 bps commission, long-only, SL/TP
- Starting cash SAR 1,000,000, empty book (persist key `abdullah-bank-desk-v2`)
- 12 agents; Grok (`grok-4.5` via `XAI_API_KEY`) when present, else local quant
- Poll tape 30s when TASI open, 180s when closed; news every 3 min
- Auth OFF, database OFF — paper book is localStorage only

## File map

### Frontend
- `src/routes/index.tsx` — desk, watchlist, ticket, wire
- `src/routes/agents.tsx` — 12-agent grid
- `src/routes/portfolio.tsx` — positions, allocation pie
- `src/routes/orders.tsx` — blotter
- `src/routes/performance.tsx` — equity curve
- `src/routes/system.tsx` — breakers, reset to cash
- `src/routes/__root.tsx` — shell, fonts, providers
- `src/components/layout/app-shell.tsx` — nav, TASI/session, refresh
- `src/components/desk/*` — ticket, sparkline, run-agent, tiles
- `src/styles.css` — tokens (charcoal/bone/steel/up/down)

### Backend (server functions, same app)
- `src/lib/desk/market.ts` — `loadMarketTape`, `loadMarketWire` (Yahoo + RSS)
- `src/lib/desk/run-agent.ts` — `runDeskAgent` (Grok JSON, quant fallback)
- `src/lib/desk/use-market-feed.ts` — client poll loop
- `src/lib/desk/store.ts` — paper broker
- `src/lib/desk/assets.ts` — TASI universe + NAME_KEYS
- `src/lib/desk/snapshot.ts` — agent input (RSI, beta vs TASI, 52w, Brent)
- `src/lib/desk/indicators.ts` — RSI, SMA, vol, beta
- `src/lib/desk/types.ts` — shared types
- `src/lib/desk/agents.ts` — agent catalog

## Constraints (Grok App Builder)

- Listen `0.0.0.0:8080`, `npm run dev` via `startup.sh`, never start Vite raw
- No `.env` file; `XAI_API_KEY` is injected server-side
- Do not mock AI if the key exists; do not call Grok on page load
- Do not add auth/db unless the user asks for accounts
- Paper ≠ live broker. Say so. Do not claim Al Rajhi/Derayah routing without their API

## Likely next asks

1. Split into FastAPI backend + Next frontend (original spec)
2. Live broker / order routing (needs credentials)
3. Accounts + Postgres so the book follows the user
4. More TASI names, fundamentals (PE, mkt cap — Yahoo quoteSummary is 401)
5. Intraday 5m bars while the session is open

Original architecture dump: `docs/abdullahnote.md`.
